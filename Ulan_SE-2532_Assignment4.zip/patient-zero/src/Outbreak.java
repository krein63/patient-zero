public class Outbreak {
    public static boolean[] cheapestTests(int n, int[][] nb, int[] cost) {
        boolean[] chosen = new boolean[n];
        if (n == 0) return chosen;
        long[][] dp = new long[n][2];
        fill(0, -1, nb, cost, dp);
        rebuild(0, -1, dp[0][1] < dp[0][0], nb, dp, chosen);
        return chosen;
    }
    private static void fill(int v, int parent, int[][] nb, int[] cost, long[][] dp) {
        dp[v][1] = cost[v];
        for (int child : nb[v]) if (child != parent) {
            fill(child, v, nb, cost, dp);
            dp[v][0] += dp[child][1];
            dp[v][1] += Math.min(dp[child][0], dp[child][1]);
        }
    }
    private static void rebuild(int v, int parent, boolean selected, int[][] nb, long[][] dp, boolean[] chosen) {
        chosen[v] = selected;
        for (int child : nb[v]) if (child != parent)
            rebuild(child, v, !selected || dp[child][1] < dp[child][0], nb, dp, chosen);
    }
    public static int longestChain(int n, int[][] nb) {
        if (n == 0) return 0;
        int[] diameter = {0};
        depth(0, -1, nb, diameter);
        return diameter[0];
    }
    private static int depth(int v, int parent, int[][] nb, int[] diameter) {
        int first = 0, second = 0;
        for (int child : nb[v]) if (child != parent) {
            int d = 1 + depth(child, v, nb, diameter);
            if (d > first) { second = first; first = d; }
            else if (d > second) second = d;
        }
        diameter[0] = Math.max(diameter[0], first + second);
        return first;
    }
}
