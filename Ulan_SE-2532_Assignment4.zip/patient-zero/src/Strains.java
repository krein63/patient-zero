public class Strains {
    public static int editDistance(String a, String b) {
        int[][] d = new int[a.length() + 1][b.length() + 1];
        for (int i = 0; i <= a.length(); i++) d[i][0] = i;
        for (int j = 0; j <= b.length(); j++) d[0][j] = j;
        for (int i = 1; i <= a.length(); i++)
            for (int j = 1; j <= b.length(); j++) {
                int replace = d[i-1][j-1] + (a.charAt(i-1) == b.charAt(j-1) ? 0 : 1);
                d[i][j] = Math.min(replace, Math.min(d[i-1][j] + 1, d[i][j-1] + 1));
            }
        return d[a.length()][b.length()];
    }
    public static int lcsLength(String a, String b) {
        int[][] d = new int[a.length() + 1][b.length() + 1];
        for (int i = 1; i <= a.length(); i++)
            for (int j = 1; j <= b.length(); j++)
                d[i][j] = a.charAt(i-1) == b.charAt(j-1) ? d[i-1][j-1] + 1 : Math.max(d[i-1][j], d[i][j-1]);
        return d[a.length()][b.length()];
    }
}
