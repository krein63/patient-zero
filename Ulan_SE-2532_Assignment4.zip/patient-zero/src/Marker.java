import java.util.*;

public class Marker {
    public static int[] prefixFunction(String p) {
        int[] pi = new int[p.length()];
        for (int i = 1; i < p.length(); i++) {
            int j = pi[i-1];
            while (j > 0 && p.charAt(i) != p.charAt(j)) j = pi[j-1];
            if (p.charAt(i) == p.charAt(j)) j++;
            pi[i] = j;
        }
        return pi;
    }
    public static int[] findAll(String text, String p) {
        if (p.isEmpty()) return new int[0];
        int[] pi = prefixFunction(p);
        List<Integer> hits = new ArrayList<>();
        int j = 0;
        for (int i = 0; i < text.length(); i++) {
            while (j > 0 && text.charAt(i) != p.charAt(j)) j = pi[j-1];
            if (text.charAt(i) == p.charAt(j)) j++;
            if (j == p.length()) {
                hits.add(i - p.length() + 1);
                j = pi[j-1];
            }
        }
        return hits.stream().mapToInt(Integer::intValue).toArray();
    }
    private static final long MOD = 1_000_000_007L, BASE = 257;
    public static int sharedWords(String a, String b, int k) {
        if (k <= 0 || k > a.length() || k > b.length()) return 0;
        long power = 1, hashB = 0, hashA = 0;
        for (int i = 1; i < k; i++) power = power * BASE % MOD;
        for (int i = 0; i < k; i++) {
            hashA = (hashA * BASE + a.charAt(i)) % MOD;
            hashB = (hashB * BASE + b.charAt(i)) % MOD;
        }
        Map<Long, List<Integer>> windows = new HashMap<>();
        for (int i = 0; i <= b.length() - k; i++) {
            windows.computeIfAbsent(hashB, x -> new ArrayList<>()).add(i);
            if (i < b.length() - k) hashB = next(hashB, b.charAt(i), b.charAt(i+k), power);
        }
        int count = 0;
        for (int i = 0; i <= a.length() - k; i++) {
            List<Integer> candidates = windows.get(hashA);
            if (candidates != null) for (int start : candidates) {
                int j = 0;
                while (j < k && a.charAt(i+j) == b.charAt(start+j)) j++;
                if (j == k) { count++; break; }
            }
            if (i < a.length() - k) hashA = next(hashA, a.charAt(i), a.charAt(i+k), power);
        }
        return count;
    }
    private static long next(long h, char oldChar, char newChar, long power) {
        return (((h - oldChar * power % MOD + MOD) % MOD) * BASE + newChar) % MOD;
    }
}
