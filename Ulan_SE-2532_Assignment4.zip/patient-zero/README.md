# Assignment 4. Patient Zero

Student ID / barcode: 251669  
Name: Ulan  
Group: SE-2532

## Program output

```text
Mutations: 91
Shared core: 1149
Marker hits: 6
First hit: 12332
Border length: 3
Shared words: 489
Tests needed: 35
Cheapest testing: 144
Longest chain: 25
```

The generated interactive report is `output/outbreak.html`. Open it in a browser. A screenshot named `output/outbreak.png` still needs to be taken and added before submission.

## Questions

1. **Edit distance.** `d[i][j]` is the minimum number of insertions, deletions and substitutions needed to convert the first `i` letters of A into the first `j` letters of B. The cell is the minimum of deleting the last letter, inserting a letter, or matching/replacing the last letter; the empty-prefix row and column are initialized with their lengths.

2. **LCS.** A subsequence keeps the order of letters but can skip letters; a substring must be consecutive. Shared core can be larger than the number of matching positions because matching letters can appear at different indices after insertions or deletions.

3. **KMP.** The prefix function gives, for each prefix, the length of its longest proper prefix that is also its suffix. On a mismatch KMP uses this information to change the pattern position while never moving backward in the text. The marker `GGTCGGGT` has border length 3: its prefix `GGT` is also its suffix.

4. **Rabin–Karp.** Different words can have the same hash, so matching hashes must be followed by a letter-by-letter check. Many collisions can cause many comparisons: worst-case time can reach O((n-k+1)(m-k+1)k), where n and m are the strain lengths and k is the window length.

5. **Tree DP.** For each person, one state is the minimum cost when the person is tested and the other when they are not. If tested, each child can use its cheaper state; otherwise every child must be tested. Choosing the person with most links ignores test prices and how choices interact, so it need not minimize total cost.

## AI use

ChatGPT generated the implementations and helped prepare the report and check the supplied examples. Review, understand, and revise the code and explanations yourself before submission. No external code sources were used.

## Timing

Measured in milliseconds, average of 3 runs, using `java -cp out Bench` in the provided execution environment.

| Test | Size | Time (ms) |
|---|---:|---:|
| Naive search | 20,000 / 40,000 / 80,000 | 12.1 / 16.5 / 34.4 |
| KMP | 20,000 / 40,000 / 80,000 | 4.1 / 1.6 / 0.9 |
| Edit distance | 500 / 1,000 / 2,000 / 4,000 | 7.1 / 6.1 / 10.1 / 30.7 |

With a fixed pattern, naive search and KMP have linear growth in the text length; the naive search performs many more comparisons on this input. Edit distance takes quadratic time when both strings grow equally. Short measurements are affected by JVM warm-up and allocation, so these measured values do not reliably show the expected doubling ratios.

## Complexity

Let n and m be the lengths of the two input strings, k the window size, v the number of people, and h the number of KMP matches.

| Algorithm | Time | Space | Assumptions |
|---|---|---|---|
| Edit distance | O(nm) | O(nm) | Full DP table |
| LCS | O(nm) | O(nm) | Full DP table |
| Prefix function and KMP | O(n+m) | O(m+h) | n is text length, m is marker length; output included |
| Rabin–Karp | O(n+m+Ck), worst O(nmk) | O(m) | C is the number of candidate comparisons; expected hash-table lookup O(1) |
| Tree DP and diameter | O(v) | O(v) | Tree adjacency and recursion; n-1 links |

## Before submission

- All three supplied examples pass, and the four personalized input files are in `data`.
- Take a screenshot of the interactive report and add `output/outbreak.png`.
- Review the implementation and rewrite the explanations in your own words; the course requires understanding the submitted work and disclosure of AI use.
- The starter was completed in a single preparation session. Create an accurate git history; the required mission-by-mission commits have not been made. Publish a public GitHub repository and submit its link in Moodle.
